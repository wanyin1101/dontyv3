'use client';

import { client } from "@/app/client";
import { useState } from "react";
import { getContract } from "thirdweb";
import { baseSepolia } from "thirdweb/chains";
import { deployPublishedContract } from "thirdweb/deploys";
import { useActiveAccount, useReadContract } from "thirdweb/react";
import Navbar from "@/app/components/Navbar"; // <-- 1) Import your Navbar component



export default function TransactionsPage() {
    return (
      <main className="min-h-screen bg-white dark:bg-zinc-950 transition-colors duration-300">
      <Navbar />
        <main>
          <div className="flex flex-row justify-between items-center mb-8">
            <p className="text-4xl font-semibold">Transactions</p>
          </div>
        </main>
      </main>
    );
}
