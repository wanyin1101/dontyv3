"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { footer } from "framer-motion/client";

// 1) Define a simple fade-in-up variant (can be reused for each section)
const fadeInUpVariants = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0 },
};

export default function Home() {
  // Dark Mode State & Effects
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const storedTheme = localStorage.getItem("theme");
    const isDark = storedTheme === "dark";
    setIsDarkMode(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode((prev) => {
      const newMode = !prev;
      document.documentElement.classList.toggle("dark", newMode);
      localStorage.setItem("theme", newMode ? "dark" : "light");
      return newMode;
    });
  };

  return (
    <main className="min-h-screen flex flex-col bg-white dark:bg-zinc-950 transition-colors duration-300">

    <motion.section
      id="hero"
      className="
        relative
        h-screen
        text-white
        bg-no-repeat bg-cover bg-center
        bg-[url('/colur_webpage_v3.png')]
        dark:bg-[url('/bg_colur_webpage_v3.png')]
      "
      variants={fadeInUpVariants}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.8 }}
    >
      {/* Dynamic Gradient Overlay */}
      <div className="absolute inset-0 dynamic-gradient" />

      {/* Icon at top-left */}
      <motion.div
        className="absolute top-8 left-6 z-20"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.5, duration: 1 }}
      >
        <a href="#content" className="inline-block hover:opacity-90 transition">
          <Image
            src="/donty.svg"
            alt="Donty Icon"
            width={300}
            height={300}
            className="mb-4"
          />
        </a>
      </motion.div>

      {/* Heading with delayed entry */}
      <div className="relative w-full h-full flex flex-col items-center justify-center px-4">
        <a href="#content" className="hover:underline">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.5, duration: 1 }}
            className="font-caveat text-5xl text-center hover:text-white transition"
          >
            The fragrance always stays in the hand that gives the rose.
          </motion.h1>
        </a>
      </div>
    </motion.section>

      {/* CONTENT SECTION */}
      <motion.section
        id="content"
        className="py-16 bg-gray-50 dark:bg-zinc-900"
        variants={fadeInUpVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container max-w-screen-lg mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">
            Welcome to Donty(Donate to you)
          </h2>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            {/* Launch App Button */}
            <Link href="/main">
              <button className="px-8 py-3 text-lg font-semibold 
                                border-2 border-pink-400 text-pink-400 rounded 
                                hover:bg-pink-400 hover:text-white transition">
                Launch App
              </button>
            </Link>

            {/* Dark Mode Toggle Button */}
            <button
              onClick={toggleDarkMode}
              className="flex items-center justify-center gap-2 
                         px-8 py-3 text-lg font-semibold 
                         border-2 border-blue-400 text-blue-400 rounded 
                         hover:bg-blue-400 hover:text-white transition 
                         focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Toggle Dark Mode"
            >
              <img
                src={isDarkMode ? "/sun.svg" : "/moon.svg"}
                alt="Theme Toggle"
                className="h-5 w-5 theme-icon"
              />
              <span className="text-gray-800 dark:text-gray-200">
                {isDarkMode ? "Light Mode" : "Dark Mode"}
              </span>
            </button>
            
            {/* Documentation Button */}
            <a
              href="https://wanyins-organization.gitbook.io/donty-docs"
              target="_blank"
              rel="noopener noreferrer"
            >
              <button
                className="px-8 py-3 text-lg font-semibold 
                          border-2 border-green-400 text-green-400 rounded 
                          hover:bg-green-400 hover:text-white transition"
              >
                View Docs
              </button>
            </a>
          </div>



          {/* Content row (image + text) */}
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-full md:w-1/2">
              <Image
                src="/donty.svg"
                alt="Content Illustration"
                width={600}
                height={400}
                className="w-full h-auto rounded shadow"
              />
            </div>
            <div className="w-full md:w-1/2">
              <p className="mb-4">
                A charitable decentralized application (dApp) designed to help
                non-profit organizations raise funds and ensure transparency through Web3 technologies.
              </p>
              <p className="mb-4">
                Donty creates more efficient, transparent, secure, and decentralized
                systems, empowering donors and recipients while fostering trust
                and amplifying impact.
              </p>
            </div>
          </div>
        </div>
      </motion.section>

      {/* FEATURES SECTION */}
      <motion.section
        id="features"
        className="py-16"
        variants={fadeInUpVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container max-w-screen-xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Features</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature #1 */}
            <div className="p-8 bg-white dark:bg-zinc-800 rounded shadow">
              <h3 className="text-xl font-semibold mb-2">Transparency</h3>
              <p className="text-sm">
                Donations are recorded on the blockchain for real-time tracking.
              </p>
            </div>
            {/* Feature #2 */}
            <div className="p-8 bg-white dark:bg-zinc-800 rounded shadow">
              <h3 className="text-xl font-semibold mb-2">Automation</h3>
              <p className="text-sm">
                Funds are automatically released to charities via a smart contract.
              </p>
            </div>
            {/* Feature #3 */}
            <div className="p-8 bg-white dark:bg-zinc-800 rounded shadow">
              <h3 className="text-xl font-semibold mb-2">Reduced Costs &amp; Time</h3>
              <p className="text-sm">
                Enjoy faster, low-cost transactions through Base.
              </p>
            </div>
            {/* Feature #4 */}
            <div className="p-8 bg-white dark:bg-zinc-800 rounded shadow">
              <h3 className="text-xl font-semibold mb-2">Global Accessibility</h3>
              <p className="text-sm">
                Enables worldwide contributions through Web3 wallets.
              </p>
            </div>
          </div>
        </div>
      </motion.section>

      {/* TEAM SECTION */}
      <motion.section
        id="team"
        className="py-16 bg-gray-50 dark:bg-zinc-900"
        variants={fadeInUpVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container max-w-screen-lg mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Meet the Team</h2>
          {/* Example single flex row */}
          <div className="flex justify-center">
            <div className="text-center p-4 bg-white dark:bg-zinc-800 rounded shadow">
              <Image
                src="/cat.jpg"
                alt="Team Member 1"
                width={120}
                height={120}
                className="mx-auto rounded-full mb-4"
              />
              <h3 className="font-semibold text-lg">CheungWanYin</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Polyu infoSecurity
              </p>
            </div>
          </div>
        </div>
      </motion.section>

      {/* FAQ SECTION */}
      <motion.section
        id="faq"
        className="py-16"
        variants={fadeInUpVariants}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container max-w-screen-2xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {/* FAQ #1 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                Is KYC required for donors or recipients?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                Donty does basic vetting on listed charities. Donors can review documentation,
                community feedback, and on-chain data for credibility.
              </p>
            </details>
            {/* FAQ #2 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                How do I verify the legitimacy of a charity?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                KYC isn’t mandatory on Donty. Some organizations or jurisdictions may require additional identity checks.
              </p>
            </details>
            {/* FAQ #3 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                Can I integrate my existing wallet?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                We support MetaMask, OKX web3 wallet, and others. 
                For Web2 logins, we offer Google, Facebook, and Apple.
              </p>
            </details>
            {/* FAQ #4 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                Where is Donty deployed?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                Donty is currently deployed on the
                <a
                  href="https://chainlist.org/chain/84532?testnets=true"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline ml-1"
                >
                  Base Sepolia testnet
                </a>
                .
              </p>
            </details>
            {/* FAQ #5 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                How do I get Base Sepolia ETH?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                You can obtain Base Sepolia ETH from various faucets. Here is the
                <a
                  href="https://docs.base.org/docs/tools/network-faucets/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 underline ml-1"
                >
                  Base_Doc
                </a>
                .
              </p>
            </details>
            {/* FAQ #6 */}
            <details className="p-4 bg-gray-50 dark:bg-zinc-900 rounded cursor-pointer">
              <summary className="font-semibold text-lg select-none">
                Are there any fees for using Donty?
              </summary>
              <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                Donty charges minimal fees for network costs. Donors still see exactly how much goes to each recipient.
              </p>
            </details>
          </div>
        </div>
      </motion.section>

      {/* FOOTER SECTION */}
      <footer className="w-full py-6 bg-gray-100 dark:bg-zinc-900 mt-auto">
        <div className="container max-w-screen-lg mx-auto px-4 flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          {/* Footer Text */}
          <p className="text-sm text-gray-700 dark:text-gray-300">
            &copy; {new Date().getFullYear()} CheungWanYin FYP Website. All rights reserved.
          </p>

          {/* Footer Navigation Links */}
          <div className="flex space-x-4 text-sm">
            <a href="#features" className="hover:underline">
              Features
            </a>
            <a href="#content" className="hover:underline">
              Content
            </a>
            <a href="#team" className="hover:underline">
              Team
            </a>
            <a href="#faq" className="hover:underline">
              FAQ
            </a>
          </div>

          {/* Footer Buttons */}
          <div className="flex space-x-4">
            {/* Launch App Button */}
            <Link href="/main">
              <button
                className="px-4 py-2 text-sm font-semibold 
                          border border-pink-400 text-pink-400 rounded 
                          hover:bg-pink-400 hover:text-white transition"
              >
                Launch App
              </button>
            </Link>

            {/* Documentation Button */}
            <a
              href="https://wanyins-organization.gitbook.io/donty-docs"
              target="_blank"
              rel="noopener noreferrer"
            >
              <button
                className="px-4 py-2 text-sm font-semibold 
                          border border-green-400 text-green-400 rounded 
                          hover:bg-green-400 hover:text-white transition"
              >
                View Docs
              </button>
            </a>
            {/* Dark Mode Toggle Button */}
            <button
                onClick={toggleDarkMode}
                className="p-2 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-label="Toggle Dark Mode"
            >
              <img
                src={isDarkMode ? '/sun.svg' : '/moon.svg'}
                alt="Theme Toggle"
                className="h-6 w-6 theme-icon"
              />
            </button>
          </div>
        </div>
      </footer>

    </main>
  );
}
